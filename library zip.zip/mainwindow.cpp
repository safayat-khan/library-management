#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui-> centralstackwidget ->setCurrentIndex(0);
    db = QSqlDatabase :: addDatabase ("QSQLITE");
    db.setDatabaseName("D:\librarymm\librarydb.db");
    qDebug() << db.open();
}

MainWindow::~MainWindow()
{
    db.close();
    delete ui;
}


void MainWindow::on_login_Button_clicked()
{
     QString login_username = ui->input_login_username->text();

     QString login_password = ui->input_login_password->text();
     ui-> centralstackwidget ->setCurrentIndex(3);
     ui -> input_login_username-> clear();
     ui->input_login_password->clear();

}


void MainWindow::on_sigup_Button_clicked()
{
     ui-> centralstackwidget ->setCurrentIndex(1);

}


void MainWindow::on_createButton_clicked()
{
      signup_username = ui->input_signup_username->text();
      signup_name = ui->input_signup_name->text();
      signup_password = ui->input_signup_password->text();
     QSqlQuery query;
     query.prepare("INSERT INTO user (username, name, password) VALUES ('"+signup_username+"', '"+signup_name+"', '"+signup_password+"')");
     if (query.exec()){
         QMessageBox::information(this, "Sign up", "Successfully signed up!!");
     }
     else {
         QMessageBox::warning(this, "Sign up", "UnSuccessfully signed up!!");
     }
     ui->input_signup_username-> clear();
     ui->input_signup_name-> clear();
     ui->input_signup_password-> clear();
    ui-> centralstackwidget ->setCurrentIndex(3);
}


void MainWindow::on_backButton_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(0);
}


void MainWindow::on_forget_password_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(2);
    QString username = ui->input_forgetpassword_username->text();
    QString name = ui->input_forgetpassword_name->text();
    QString newpass = ui->input_forgetpassword_new_password->text();


}


void MainWindow::on_submitButton_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);
}


void MainWindow::on_backButton_2_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(0);
}


void MainWindow::on_manage_genre_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(4);

}


void MainWindow::on_genre_add_clicked()
{
    QString gID= ui->genre_ID->text();
    QString gname = ui->genre_Name->text();

}

void MainWindow::on_genre_back_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);

}

void MainWindow::on_manage_authors_button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(5);

}


void MainWindow::on_addButtton_clicked()
{
    QString aut_ID = ui->author_ID->text();
    QString aut_firstName = ui->author_firstName->text();
    QString aut_lastName = ui->author_lastName->text();
    QString aut_expertise = ui->author_expertise->text();
    QString aut_about = ui->author_about->toPlainText();
}

void MainWindow::on_backButton_3_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);

}

void MainWindow::on_add_member_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(6);

}

void MainWindow::on_addMemberButton_clicked()
{
    QString adm_firstName =ui->addmem_firstName->text();
    QString adm_lastName = ui->addmem_lastName->text();
    QString  adm_phone = ui->addmem_phone->text();
    QString adm_email = ui->addmem_email->text();

}


void MainWindow::on_backButton_4_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);

}


void MainWindow::on_edit_member_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(7);

}


void MainWindow::on_editMemberBtn_clicked()
{
    QString editmem_ID = ui->editmem_ID->text();
    QString editmem_firstName = ui->editmem_firstName->text();
    QString editmem_lastName = ui->editmem_lastName->text();
    QString editmem_phone = ui->editmem_phone->text();;
    QString editmem_mail = ui->editmem_email->text();
    QString editmem_gender = ui->gender_2->currentText();
}


void MainWindow::on_editmem_back_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);

}


void MainWindow::on_delete_member_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(8);

}


void MainWindow::on_deleteMemberBtn_clicked()
{
    QString dltmem_ID = ui->deletemem_ID->text();
}


void MainWindow::on_dltmem_back_btn_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);
}



void MainWindow::on_add_book_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(9);

}


void MainWindow::on_cancelBtn_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);
}


void MainWindow::on_delete_book_Button_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(10);

}


void MainWindow::on_deleteBook_backBtn_clicked()
{
    ui-> centralstackwidget ->setCurrentIndex(3);

}

