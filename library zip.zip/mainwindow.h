#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>


#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_login_Button_clicked();

    void on_sigup_Button_clicked();

    void on_createButton_clicked();

    void on_backButton_clicked();

    void on_pushButton_clicked();

    void on_forget_password_Button_clicked();

    void on_submitButton_clicked();

    void on_backButton_2_clicked();

    void on_pushButton_2_clicked();

    void on_manage_genre_Button_clicked();

    void on_genre_add_clicked();

    void on_manage_authors_button_clicked();

    void on_addButtton_clicked();

    void on_genre_edit_clicked();

    void on_genre_back_clicked();

    void on_editButton_clicked();

    void on_addMemberButton_clicked();

    void on_backButton_3_clicked();

    void on_add_member_Button_clicked();

    void on_backButton_4_clicked();

    void on_edit_member_Button_clicked();

    void on_editMemberBtn_clicked();

    void on_editmem_back_clicked();

    void on_delete_member_Button_clicked();

    void on_deleteMemberBtn_clicked();

    void on_dltmem_back_btn_clicked();

    void on_member_list_Button_clicked();

    void on_add_book_Button_clicked();

    void on_cancelBtn_clicked();

    void on_delete_book_Button_clicked();

    void on_deleteBook_backBtn_clicked();

private:
    Ui::MainWindow *ui;
    QString username,name,password;
    QString signup_username,signup_name,signup_password;
    QSqlDatabase db;
};
#endif // MAINWINDOW_H
